
import java.util.HashMap;

public class Sorting {

	public static<T extends Comparable<T>> void insertionSort(T[] list, int i, int j) {
		//TODO: IMPLEMENT THIS METHOD
	}
	
	private static<T extends Comparable<T>> void quickSort(T[] list, int i, int j, int minSize) {
		//TODO HELPER METHOD FOR QUICKSORT THAT TAKES IN INDICES
	}
	
	private static<T extends Comparable<T>> int partition(T[] list, int i, int j) {
		//TODO: PARTITION THE PORTION OF THE LIST BETWEEN i AND j
	}

}
