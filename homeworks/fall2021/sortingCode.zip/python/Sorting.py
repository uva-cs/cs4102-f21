
def insertionSort(list, i, j):
	#TODO: IMPLEMENT THIS METHOD

def partition(list, i, j):
	#TODO: PARTITION FOR QUICKSORT

def quickSort(list, i, j, minSize):
	#TODO: IMPLEMENT QUICKSORT (THIS ONE IS THE ONE CALLED BY THE DRIVER) 
