
#include <iostream>
#include <vector>

using namespace std;


void insertionSort(vector<int> &list, int i, int j) {
	//TODO: WRITE THIS METHOD
}


int partition(vector<int> &list, int i, int j) {
	//TODO: PROBABLY WANT THIS FOR QUICKSORT
}

void quickSort(vector<int> &list, int i, int j, int minSize) {
	//TODO: WRITE THIS METHOD
}

